# Download

## v{RELEASE} release

* Download [TGZ](https://github.com/openucx/ucx/releases/download/v{RELEASE}/ucx-{RELEASE}.tar.gz) [SRPM](https://github.com/openucx/ucx/releases/download/v{RELEASE}/ucx-{RELEASE}-1.fc30.src.rpm)
* [Release page](https://github.com/openucx/ucx/releases/tag/v{RELEASE})
* [Running](running)

<br/>

## Previous releases

[GitHub release page](https://github.com/openucx/ucx/releases)
