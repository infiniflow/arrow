// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

void do_something_in_b();
