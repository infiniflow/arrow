Performance Tests - Benchmarks
==============================

Click `here <https://open-telemetry.github.io/opentelemetry-cpp/benchmarks/index.html>`_ to view the latest performance benchmarks for packages in this repo.

Please note that the flutation in the results are mainly because `machines with different CPUs <https://github.com/benchmark-action/github-action-benchmark/issues/79>`_ are used for tests.
