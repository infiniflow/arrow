This directory is used to store build artifacts (tarballs and source) for a locally
built copy of libcrypto, either from OpenSSL, LibreSSL or BoringSSL.

See the s2n [Usage Guide](https://github.com/aws/s2n-tls/blob/main/docs/USAGE-GUIDE.md) for more details.
